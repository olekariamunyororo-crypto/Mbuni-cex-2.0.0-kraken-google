"use client";

import { useOpenCEX } from "@/lib/opencex/store";
import { useBinanceFeed } from "@/lib/opencex/use-binance-feed";
import { OrderBook } from "@/components/opencex/order-book";
import { TradeTape } from "@/components/opencex/trade-tape";
import { PriceChart } from "@/components/opencex/price-chart";
import { OrderEntry } from "@/components/opencex/order-entry";
import { OpenOrders } from "@/components/opencex/open-orders";
import { PairSelector } from "@/components/opencex/pair-selector";
import { MobileOrderSheet } from "@/components/opencex/mobile-order-sheet";
import { fmtPrice, fmtPct, fmtCompact } from "@/lib/opencex/format";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, ListOrdered, Receipt } from "lucide-react";

type MobileTab = "book" | "trades" | "orders";

export function TradingView() {
  useBinanceFeed();

  const activePair = useOpenCEX((s) => s.activePair);
  const ticker = useOpenCEX((s) => s.tickers[activePair]);
  const [showOpen, setShowOpen] = useState(true);
  const [mobileTab, setMobileTab] = useState<MobileTab>("book");

  return (
    <div className="flex flex-col h-[calc(100vh-3.5rem)]">
      {/* Pair selector + ticker bar */}
      <div className="px-3 py-2 flex items-center gap-3 flex-wrap">
        <PairSelector />
        {ticker && (
          <div className="hidden lg:flex items-center gap-5 text-xs">
            <Stat label="Last" value={fmtPrice(ticker.lastPrice, 2)} />
            <Stat label="24h" value={`${fmtPrice(ticker.priceChange, 2)} (${fmtPct(ticker.priceChangePct)})`} tone={ticker.priceChangePct >= 0 ? "up" : "down"} />
            <Stat label="High" value={fmtPrice(ticker.high, 2)} />
            <Stat label="Low" value={fmtPrice(ticker.low, 2)} />
            <Stat label="Vol" value={fmtCompact(ticker.volume)} suffix={activePair.split("/")[0]} />
            <Stat label="Vol (USDT)" value={fmtCompact(ticker.quoteVolume)} />
          </div>
        )}
        <div className="hidden lg:flex flex-1" />
        <button onClick={() => setShowOpen(!showOpen)} className="hidden lg:block text-[11px] text-tertiary hover:text-foreground">
          {showOpen ? "Hide" : "Show"} orders
        </button>
      </div>

      {/* Mobile ticker strip */}
      {ticker && (
        <div className="lg:hidden px-3 py-1.5 flex items-center gap-3 overflow-x-auto no-scrollbar">
          <Stat label="24h" value={fmtPct(ticker.priceChangePct)} tone={ticker.priceChangePct >= 0 ? "up" : "down"} compact />
          <Stat label="High" value={fmtPrice(ticker.high, 2)} compact />
          <Stat label="Low" value={fmtPrice(ticker.low, 2)} compact />
          <Stat label="Vol" value={fmtCompact(ticker.quoteVolume)} compact suffix="USDT" />
        </div>
      )}

      {/* Desktop layout */}
      <div className="hidden md:grid md:grid-cols-12 flex-1 gap-3 p-3 pt-0 min-h-0">
        {/* Order book */}
        <div className="col-span-3 glass-card overflow-hidden">
          <OrderBook pair={activePair} />
        </div>

        {/* Chart + orders */}
        <div className="col-span-6 glass-card flex flex-col overflow-hidden">
          <div className="flex-1 min-h-0">
            <PriceChart pair={activePair} />
          </div>
          {showOpen && (
            <div className="h-56 border-t border-white/[0.04] overflow-hidden">
              <OpenOrders pair={activePair} />
            </div>
          )}
        </div>

        {/* Trade tape + order entry */}
        <div className="col-span-3 flex flex-col gap-3 overflow-hidden">
          <div className="h-1/2 glass-card overflow-hidden">
            <TradeTape pair={activePair} />
          </div>
          <div className="h-1/2 glass-card overflow-hidden">
            <OrderEntry pair={activePair} />
          </div>
        </div>
      </div>

      {/* Mobile layout */}
      <div className="md:hidden flex-1 flex flex-col min-h-0 px-3 pb-2">
        <div className="h-[42vh] min-h-[260px] glass-card overflow-hidden mb-2">
          <PriceChart pair={activePair} />
        </div>
        <div className="flex-1 glass-card overflow-hidden">
          <Tabs value={mobileTab} onValueChange={(v) => setMobileTab(v as MobileTab)} className="h-full flex flex-col">
            <TabsList className="grid grid-cols-3 rounded-none border-b border-white/[0.04] h-9" style={{ background: "rgba(255,255,255,0.02)" }}>
              <TabsTrigger value="book" className="text-xs gap-1 data-[state=active]:text-primary"><BookOpen className="w-3 h-3" /> Book</TabsTrigger>
              <TabsTrigger value="trades" className="text-xs gap-1 data-[state=active]:text-primary"><Receipt className="w-3 h-3" /> Trades</TabsTrigger>
              <TabsTrigger value="orders" className="text-xs gap-1 data-[state=active]:text-primary"><ListOrdered className="w-3 h-3" /> Orders</TabsTrigger>
            </TabsList>
            <TabsContent value="book" className="flex-1 mt-0 overflow-hidden min-h-0"><OrderBook pair={activePair} /></TabsContent>
            <TabsContent value="trades" className="flex-1 mt-0 overflow-hidden min-h-0"><TradeTape pair={activePair} /></TabsContent>
            <TabsContent value="orders" className="flex-1 mt-0 overflow-hidden min-h-0"><OpenOrders pair={activePair} /></TabsContent>
          </Tabs>
        </div>
      </div>

      <MobileOrderSheet pair={activePair} />
    </div>
  );
}

function Stat({ label, value, tone, suffix, compact }: { label: string; value: string; tone?: "up" | "down"; suffix?: string; compact?: boolean }) {
  const color = tone === "up" ? "text-primary" : tone === "down" ? "text-danger" : "text-foreground";
  return (
    <div className={`flex ${compact ? "flex-row items-baseline gap-1" : "flex-col"} leading-tight shrink-0`}>
      <span className="text-[10px] text-tertiary uppercase tracking-wider">{label}</span>
      <span className={`${compact ? "text-xs" : "text-xs"} font-medium tabular ${color}`}>
        {value}{suffix && <span className="text-tertiary ml-1">{suffix}</span>}
      </span>
    </div>
  );
}
