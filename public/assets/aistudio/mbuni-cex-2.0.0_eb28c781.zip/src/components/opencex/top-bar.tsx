"use client";

import { useEffect, useState } from "react";
import { Search, Bell, Settings, Activity, LogOut } from "lucide-react";
import { signOut } from "next-auth/react";
import type { ViewKey } from "@/app/page";
import { useOpenCEX } from "@/lib/opencex/store";
import { fmtPrice, fmtPct } from "@/lib/opencex/format";

const VIEW_TITLES: Record<ViewKey, { title: string; subtitle: string; short: string }> = {
  trading: { title: "Terminal", short: "Terminal", subtitle: "CLOB · Price-Time priority · Rust engine" },
  markets: { title: "Markets", short: "Markets", subtitle: "All trading pairs · 24h stats" },
  swap: { title: "Swap", short: "Swap", subtitle: "Simple spot convert · 0.1% slippage cap" },
  wallet: { title: "Wallet", short: "Wallet", subtitle: "Balances · Deposits · Withdrawals" },
  admin: { title: "History", short: "History", subtitle: "Activity · Risk · Operations" },
  architecture: { title: "Architecture", short: "Arch", subtitle: "Services · Health · Event stream" },
};

interface SessionUserLike {
  email?: string | null;
  name?: string | null;
  onboardingComplete?: boolean;
  tier?: number;
  kycStatus?: string;
}

export function TopBar({
  view,
  sessionUser,
  onLogout,
}: {
  view: ViewKey;
  sessionUser?: SessionUserLike;
  onLogout?: () => void;
}) {
  const activePair = useOpenCEX((s) => s.activePair);
  const tickers = useOpenCEX((s) => s.tickers);
  const feedConnected = useOpenCEX((s) => s.feedConnected);
  const liveMode = useOpenCEX((s) => s.liveMode);
  const meta = VIEW_TITLES[view];
  const ticker = tickers[activePair];

  const [now, setNow] = useState<string>("");
  useEffect(() => {
    const tick = () => setNow(new Date().toLocaleTimeString("en-US", { hour12: false }));
    tick();
    const i = setInterval(tick, 1000);
    return () => clearInterval(i);
  }, []);

  return (
    <header className="h-14 shrink-0 flex items-center px-3 md:px-4 gap-2 md:gap-4">
      {/* Floating glass bar */}
      <div className="absolute inset-x-2 top-2 h-12 rounded-2xl glass z-0" />

      <div className="relative z-10 flex flex-col leading-tight min-w-0">
        <h1 className="text-sm font-semibold truncate">
          <span className="md:hidden">{meta.short}</span>
          <span className="hidden md:inline">{meta.title}</span>
        </h1>
        <span className="text-[11px] text-tertiary truncate hidden md:inline">{meta.subtitle}</span>
      </div>

      <div className="relative z-10 flex-1" />

      {/* Mobile compact ticker */}
      {view === "trading" && ticker && (
        <div className="md:hidden relative z-10 flex items-center gap-2 px-2.5 py-1 rounded-lg glass-chip">
          <span className="text-[11px] font-medium">{activePair}</span>
          <span className="text-sm font-semibold tabular">{fmtPrice(ticker.lastPrice, 2)}</span>
          <span className={`text-[10px] tabular ${ticker.priceChangePct >= 0 ? "text-primary" : "text-danger"}`}>
            {fmtPct(ticker.priceChangePct)}
          </span>
        </div>
      )}

      {/* Desktop full ticker */}
      {view === "trading" && ticker && (
        <div className="hidden md:flex relative z-10 items-center gap-4 px-3 py-1 rounded-lg glass-chip">
          <div className="flex flex-col leading-tight">
            <span className="text-[10px] text-tertiary">{activePair}</span>
            <span className="text-sm font-semibold tabular">{fmtPrice(ticker.lastPrice, 2)}</span>
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-[10px] text-tertiary">24h</span>
            <span className={`text-sm font-medium tabular ${ticker.priceChangePct >= 0 ? "text-primary" : "text-danger"}`}>
              {fmtPct(ticker.priceChangePct)}
            </span>
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-[10px] text-tertiary">High</span>
            <span className="text-sm font-medium tabular">{fmtPrice(ticker.high, 2)}</span>
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-[10px] text-tertiary">Low</span>
            <span className="text-sm font-medium tabular">{fmtPrice(ticker.low, 2)}</span>
          </div>
        </div>
      )}

      {/* Live indicator */}
      <div className="hidden sm:flex relative z-10 items-center gap-2 px-2.5 py-1 rounded-lg glass-chip">
        <span className="relative flex h-2 w-2">
          {feedConnected ? (
            <>
              <span className="absolute inline-flex h-full w-full rounded-full bg-primary opacity-60 live-dot" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
            </>
          ) : (
            <>
              <span className="absolute inline-flex h-full w-full rounded-full bg-warning opacity-60 live-dot" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-warning" />
            </>
          )}
        </span>
        <span className="text-[11px] text-secondary">
          {liveMode && feedConnected ? "LIVE · BINANCE" : "SIMULATED"}
        </span>
        <span className="text-[11px] text-tertiary tabular hidden lg:inline">{now}</span>
      </div>

      <button className="hidden sm:block relative z-10 p-2 rounded-lg text-tertiary hover:text-foreground transition-colors" style={{ background: "rgba(255,255,255,0.03)" }}>
        <Search className="w-4 h-4" />
      </button>
      <button className="relative z-10 p-2 rounded-lg text-tertiary hover:text-foreground transition-colors" style={{ background: "rgba(255,255,255,0.03)" }}>
        <Bell className="w-4 h-4" />
        <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-danger rounded-full" />
      </button>
      <button className="hidden sm:block relative z-10 p-2 rounded-lg text-tertiary hover:text-foreground transition-colors" style={{ background: "rgba(255,255,255,0.03)" }}>
        <Settings className="w-4 h-4" />
      </button>
      <button
        onClick={() => signOut({ redirect: false }).then(() => onLogout?.())}
        className="md:hidden relative z-10 p-2 rounded-lg text-tertiary hover:text-danger transition-colors"
        style={{ background: "rgba(255,255,255,0.03)" }}
      >
        <LogOut className="w-4 h-4" />
      </button>
    </header>
  );
}
